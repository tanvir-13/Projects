﻿using StudentManager.UI_Layer.Templates;
using StudentManager.Utilities.List;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentManager.UI_Layer.Employee
{
    public partial class ManageEmployeeForm : TemplateForm
    {
        public ManageEmployeeForm()
        {
            InitializeComponent();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ShowEmployeeInfoScreen(0, false);
        }

        private void ShowEmployeeInfoScreen(int employeeId, bool isUpdate)
        {
            EmployeeInfoForm eif = new EmployeeInfoForm();
            eif.EmployeeId = employeeId;
            eif.IsUpdate = IsUpdate;
            eif.ShowDialog();
            LoadDataIntoGridView();
        }

        private void ManageEmployeeForm_Load(object sender, EventArgs e)
        {
            LoadDataIntoGridView();
        }

        private void LoadDataIntoGridView()
        {
            ListData.LoadDataIntoGridView(EmployeesDataGridView, "usp_EmployeesGetEmployee");
        }

        private void EmployeesDataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = EmployeesDataGridView.Rows.GetFirstRow(DataGridViewElementStates.Selected);
            int employeeId = Convert.ToInt32(EmployeesDataGridView.Rows[rowIndex].Cells["EmployeeId"].Value);
            ShowEmployeeInfoScreen(employeeId, true);
        }
    }
}
