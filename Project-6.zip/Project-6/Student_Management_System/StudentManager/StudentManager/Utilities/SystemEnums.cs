﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManager.Utilities
{
    public enum ListTypes
    {
        City=1,
        District=2,
        Gender=3,
        EmployeeJobTitle=4,
        YesOrNo=5,
        EmployeeReasonLeft=6
    }
}
