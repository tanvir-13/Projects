<?php
    header ('Location:'.'Views/home.html');
?>
