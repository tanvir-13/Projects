-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2021 at 06:51 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `information`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `Username` varchar(30) NOT NULL,
  `UserID` varchar(30) NOT NULL,
  `ProductName` varchar(30) NOT NULL,
  `Price` int(10) NOT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `PaymentMethod` varchar(30) DEFAULT NULL,
  `ProductStatus` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`Username`, `UserID`, `ProductName`, `Price`, `Address`, `PaymentMethod`, `ProductStatus`) VALUES
('King', 'user1', 'Cyberpunk 2077', 60, 'house', 'Bkash', 'Accepted'),
('King', 'user1', 'Fallout 4', 50, 'house', 'Bkash', 'Accepted'),
('King', 'user1', 'FIFA 20', 45, 'house', 'Bkash', 'Accepted'),
('King', 'user1', 'Need For Speed: Heat', 30, 'house', 'Bkash', 'Accepted'),
('King', 'user1', 'Red Dead Redemption 2', 60, 'house', 'Bkash', 'Accepted'),
('queen', 'queen', 'Cyberpunk 2077', 60, 'djdjd', 'Bkash', 'Processing');

-- --------------------------------------------------------

--
-- Table structure for table `gameinfo`
--

CREATE TABLE `gameinfo` (
  `name` varchar(30) NOT NULL,
  `genre` varchar(30) NOT NULL,
  `ageRating` int(5) NOT NULL,
  `platform` varchar(30) NOT NULL,
  `synopsis` text NOT NULL,
  `developer` varchar(30) NOT NULL,
  `releasedate` varchar(30) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gameinfo`
--

INSERT INTO `gameinfo` (`name`, `genre`, `ageRating`, `platform`, `synopsis`, `developer`, `releasedate`, `price`) VALUES
('Cyberpunk 2077', 'Role Playing Game(RPG)', 18, 'PS4,XBOX ONE,PC', 'Cyberpunk 2077 is an open-world, action-adventure story set in Night City, a megalopolis obsessed with power, glamour and body modification. You play as V, a mercenary outlaw going after a one-of-a-kind implant that is the key to immortality.', 'CD PROJEKT RED', ' 16 Apr, 2020', 60),
('Death Stranding', 'Action,Adventure', 18, 'PS4,PC', 'From legendary game creator Hideo Kojima comes an all-new, genre-defying experience. Sam Bridges must brave a world utterly transformed by the Death Stranding. Carrying the disconnected remnants of our future in his hands, he embarks on a journey to reconnect the shattered world one step at a time.', 'Kojima Productions', 'Summer 2020', 45),
('Fallout 4', 'Role Playing Game', 18, 'PS4,XBOX ONE,PC', 'Bethesda Game Studios, the award-winning creators of Fallout 3 and The Elder Scrolls V: Skyrim, welcome you to the world of Fallout 4 – their most ambitious game ever, and the next generation of open-world gaming.', ' Bethesda Game Studios', ' 9 Aug, 2017', 50),
('FIFA 20', 'Sports', 10, 'PS4,XBOX ONE,PC', 'FIFA 20 is a football simulation video game published by Electronic Arts as part of the FIFA series.', 'Electronic Arts', '24 Sept, 2019', 45),
('Gears 5', 'Action,Adventure', 18, 'PS4,XBOX ONE,PC', 'From one of gaming’s most acclaimed sagas, Gears is bigger than ever, with five thrilling modes and the deepest campaign yet. With all-out war descending, Kait Diaz breaks away to uncover her connection to the enemy and discovers the true danger to Sera – herself.', ' The Coalition', ' 6 Sep, 2019', 30),
('Need For Speed: Heat', 'Racing', 13, 'PS4,XBOX ONE,PC', 'Need for Speed Heat is a racing video game developed by Ghost Games and published by Electronic Arts for Microsoft Windows, PlayStation 4 and Xbox One. It is the twenty-fourth installment in the Need for Speed series and commemorates the series\' 25th anniversary.', 'Electronic Arts', '8 Nov, 2019', 30),
('Red Dead Redemption 2', 'Action,Adventure', 18, 'PS4,XBOX ONE,PC', 'America, 1899. The end of the Wild West era has begun. After a robbery goes badly wrong in the western town of Blackwater, Arthur Morgan and the Van der Linde gang are forced to flee. With federal agents and the best bounty hunters in the nation massing on their heels, the gang must rob, steal and fight their way across the rugged heartland of America in order to survive. As deepening internal divisions threaten to tear the gang apart, Arthur must make a choice between his own ideals and loyalty to the gang who raised him.', 'Rockstar Games', '26 Oct, 2019', 60),
('Star Wars Jedi: Fallen Order', 'Action, Adventure', 16, 'PS4,XBOX ONE,PC', 'A galaxy-spanning adventure awaits in Star Wars Jedi: Fallen Order, a 3rd person action-adventure title from Respawn. An abandoned Padawan must complete his training, develop new powerful Force abilities, and master the art of the lightsaber - all while staying one step ahead of the Empire.', ' Respawn Entertainment', '15 Nov, 2019', 60),
('The Outer Worlds', 'Role Playing Game', 17, 'PS4,XBOX ONE,PC', 'The Outer Worlds is a new single-player sci-fi RPG from Obsidian Entertainment and Private Division. As you explore a space colony, the character you decide to become will determine how this player-driven story unfolds. In the corporate equation for the colony, you are the unplanned variable.', ' Obsidian Entertainment', '25 Oct, 2019', 45),
('The Witcher 3: Wild Hunt', 'Role Playing Game', 18, 'PS4,XBOX ONE,PC', 'As war rages on throughout the Northern Realms, you take on the greatest contract of your life — tracking down the Child of Prophecy, a living weapon that can alter the shape of the world.', 'CD PROJEKT RED', '18 May, 2015', 60);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `userId` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `userStatus` int(1) NOT NULL DEFAULT 1,
  `userName` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`userId`, `password`, `userStatus`, `userName`) VALUES
('jack', 'jackk', 1, 'jack'),
('pro', 'user1', 1, 'pro'),
('queen', 'queen', 1, 'queen');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gameinfo`
--
ALTER TABLE `gameinfo`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`userId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
