
import java.lang.*;


public interface interfaceGame
{
    void insertGame(Game g);
    Game getGame(String name);
    
}

